#!/bin/bash 

echo running iperf-client

#TODO: add your code
#ipref -u -c 10.0.0.1 --burst-period 0.125 --burst-size 612500000 -p 5001 -t 40  &
while true
do
    iperf  -u -c 10.0.0.1 -b 20M  -p 5003 -t 0.17 &  
    sleep 0.8
done