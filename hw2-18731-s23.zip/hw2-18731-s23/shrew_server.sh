#qsize=$1
echo set iperf-server

#TODO: add your code
iperf -u -s -p 5003 &
